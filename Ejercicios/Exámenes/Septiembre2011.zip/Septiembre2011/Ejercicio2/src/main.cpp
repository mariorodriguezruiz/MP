/*
    Examen septiembre 2012.

 */

#include<MatrizBS.h>

int main(int argc, char **argv){

}

