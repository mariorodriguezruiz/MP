var NAVTREE =
[
  [ "Bloque de LEDs", "index.html", [
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ],
      [ "Miembros de los ficheros", "globals.html", [
        [ "Todo", "globals.html", null ],
        [ "Funciones", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "'typedefs'", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"bloqueLed_8h.html"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';