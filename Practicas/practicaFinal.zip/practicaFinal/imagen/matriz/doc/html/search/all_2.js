var searchData=
[
  ['celda',['Celda',['../structCelda.html',1,'']]],
  ['columnas',['columnas',['../classImagen.html#a53d3de2d3cea5aa472bdd85941a0f020',1,'Imagen']]],
  ['crear',['crear',['../classImagen.html#a3c963c0aaa02767f65b4510cb39027ac',1,'Imagen']]]
];
