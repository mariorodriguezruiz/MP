var searchData=
[
  ['pgm_2ecpp',['pgm.cpp',['../pgm_8cpp.html',1,'']]],
  ['pgm_2eh',['pgm.h',['../pgm_8h.html',1,'']]],
  ['plano',['plano',['../classImagen.html#a275fdb0d5f4c5aefaf13c21960841371',1,'Imagen']]]
];
