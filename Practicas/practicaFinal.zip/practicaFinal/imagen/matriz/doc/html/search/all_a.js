var searchData=
[
  ['num_5fpos',['NUM_POS',['../byte_8h.html#a1534cd78f7dde3ba7636c05a9ef55e6d',1,'byte.h']]]
];
