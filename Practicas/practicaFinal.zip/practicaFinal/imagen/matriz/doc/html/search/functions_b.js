var searchData=
[
  ['plano',['plano',['../classImagen.html#a275fdb0d5f4c5aefaf13c21960841371',1,'Imagen']]]
];
