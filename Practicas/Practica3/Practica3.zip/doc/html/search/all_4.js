var searchData=
[
  ['get',['get',['../classImagen.html#ab8a0d7d44f6d22678ed7fea1e9617e25',1,'Imagen']]],
  ['getpos',['getPos',['../classImagen.html#a903bfa18bddaed521557d73d483b2087',1,'Imagen']]]
];
