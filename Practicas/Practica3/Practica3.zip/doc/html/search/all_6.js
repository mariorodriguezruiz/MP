var searchData=
[
  ['leerimagen',['leerImagen',['../classImagen.html#aa46cc99da218afa01f55395e4c96ffe0',1,'Imagen']]],
  ['leerpgmbinario',['leerPGMBinario',['../pgm_8h.html#a3d11aef73fef65e3ba31446f8fc20595',1,'leerPGMBinario(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a3d11aef73fef65e3ba31446f8fc20595',1,'leerPGMBinario(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]]
];
