var searchData=
[
  ['imagen',['Imagen',['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a7632978f5ae089713e652bb362da1e78',1,'Imagen::Imagen(int filas, int columnas)']]],
  ['infopgm',['infoPGM',['../pgm_8h.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]]
];
