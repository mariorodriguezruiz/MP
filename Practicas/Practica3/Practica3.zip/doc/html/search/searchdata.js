var indexSectionsWithContent =
{
  0: "bcefgilpst",
  1: "i",
  2: "ip",
  3: "cefgils",
  4: "b",
  5: "t",
  6: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "&apos;typedefs&apos;",
  5: "Enumeraciones",
  6: "Valores de enumeraciones"
};

